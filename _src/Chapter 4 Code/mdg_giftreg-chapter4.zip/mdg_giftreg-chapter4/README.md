mdg_giftreg
===========

Gift Registry Module for the Magento Developers Guide